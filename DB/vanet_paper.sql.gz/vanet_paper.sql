-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2021 at 03:53 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vanet_paper`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_vehicles`
--

CREATE TABLE `account_vehicles` (
  `vehicle_id` int(8) NOT NULL,
  `reference_code` varchar(200) NOT NULL,
  `vehicle_registeration_number` varchar(200) NOT NULL,
  `vehicle_nc` int(20) NOT NULL,
  `onboard_email` varchar(200) NOT NULL,
  `onboard_password` varchar(500) NOT NULL,
  `update_code_i` varchar(200) NOT NULL,
  `updated_code_s` varchar(200) NOT NULL,
  `svc_s` varchar(200) NOT NULL,
  `vca_s` varchar(200) NOT NULL,
  `vehicle_token` varchar(500) NOT NULL,
  `vehicle_registered_on` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `v2i_messages`
--

CREATE TABLE `v2i_messages` (
  `message_id` int(8) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `sender_id` int(8) NOT NULL,
  `content` varchar(500) NOT NULL,
  `message_priority` tinyint(2) NOT NULL,
  `message_date_time` varchar(300) NOT NULL,
  `message_status` tinyint(2) NOT NULL,
  `latitude` varchar(300) NOT NULL,
  `longitude` varchar(300) NOT NULL,
  `location` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `v2i_messages`
--

INSERT INTO `v2i_messages` (`message_id`, `reference`, `sender_id`, `content`, `message_priority`, `message_date_time`, `message_status`, `latitude`, `longitude`, `location`) VALUES
(1, '20210121_000001', 1, 'I Need Help.', 1, '21-01-2021 03:50:51', 1, '89587.09', '99857.01', '89587.09 99857.01');

-- --------------------------------------------------------

--
-- Table structure for table `v2v_messages`
--

CREATE TABLE `v2v_messages` (
  `message_id` int(8) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `reciever_id` int(8) NOT NULL,
  `sender_id` int(8) NOT NULL,
  `content` varchar(500) NOT NULL,
  `message_priority` tinyint(2) NOT NULL,
  `message_date_time` varchar(300) NOT NULL,
  `message_status` tinyint(2) NOT NULL,
  `latitude` varchar(300) NOT NULL,
  `longitude` varchar(300) NOT NULL,
  `location` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `v2v_messages`
--

INSERT INTO `v2v_messages` (`message_id`, `reference`, `reciever_id`, `sender_id`, `content`, `message_priority`, `message_date_time`, `message_status`, `latitude`, `longitude`, `location`) VALUES
(1, '20210121_000001', 1, 1, 'Speed Up Your Vehicle.', 1, '21-01-2021 03:41:37', 1, '89587.09', '99857.01', '89587.09 99857.01');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_logs`
--

CREATE TABLE `vehicle_logs` (
  `logs_id` int(8) NOT NULL,
  `vehicle_id` int(8) NOT NULL,
  `reference` varchar(200) NOT NULL,
  `login_date` varchar(300) NOT NULL,
  `logoff_date` varchar(300) NOT NULL,
  `login_method` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_vehicles`
--
ALTER TABLE `account_vehicles`
  ADD PRIMARY KEY (`vehicle_id`);

--
-- Indexes for table `v2v_messages`
--
ALTER TABLE `v2v_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `vehicle_logs`
--
ALTER TABLE `vehicle_logs`
  ADD PRIMARY KEY (`logs_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vehicle_logs`
--
ALTER TABLE `vehicle_logs`
  MODIFY `logs_id` int(8) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
